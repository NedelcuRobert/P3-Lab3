#include "carteJoc.h"

class CJoc21
{
private:
	CCarteJoc pachet[52];
public:
	void initializare_carti();
	void extragere();
};
