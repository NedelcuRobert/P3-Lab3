#include "joc21.h"

int main() {

	CJoc21 blackjack;

	blackjack.initializare_carti();
	blackjack.extragere();

	return 0;
}